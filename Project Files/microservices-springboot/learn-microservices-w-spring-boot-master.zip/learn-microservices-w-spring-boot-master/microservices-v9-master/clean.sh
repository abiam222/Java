find . -name '.idea' -exec rm -vr {} +
find . -name 'target' -exec rm -vr {} +
find . -name '*.iml' -delete