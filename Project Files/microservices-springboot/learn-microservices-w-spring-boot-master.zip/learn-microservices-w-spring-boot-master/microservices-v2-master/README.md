# microservices-v2

This project contains the version two of the application that is developed under the scope of the book *Learn Microservices with Spring Boot*. You can get a copy of the book on [Apress](http://www.apress.com/gp/book/9781484231647).

## About this version

We have now the implementation of the logic to get a random factor, `RandomGeneratorServiceImpl`.

Besides, we see in this version the difference between creating tests with `@SpringBootTest` and plain JUnit tests. We keep both versions so the reader can compare the implementations.
