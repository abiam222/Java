package microservices.book.testutils.beans;

/**
 * @author moises.macero
 */
public class User {

    private long id;
    private String alias;

    public User() {
    }

    public long getId() {
        return id;
    }

    public String getAlias() {
        return alias;
    }
}
