package microservices.book.testutils.beans;

import java.util.List;

/**
 * @author moises.macero
 */
public class Stats {
    private List<String> badges;
    private int score;

    public List<String> getBadges() {
        return badges;
    }

    public int getScore() {
        return score;
    }
}
