package microservices.book.testutils.beans;

/**
 * @author moises.macero
 */
public class LeaderBoardPosition {
    private Long userId;
    private Long totalScore;

    public Long getUserId() {
        return userId;
    }

    public Long getTotalScore() {
        return totalScore;
    }
}
